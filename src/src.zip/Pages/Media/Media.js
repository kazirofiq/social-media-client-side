import React from 'react';

const Media = () => {
    return (
        <div>
            <h2>This Media page</h2>
        </div>
    );
};

export default Media;