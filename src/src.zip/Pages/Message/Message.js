import React from 'react';

const Message = () => {
    return (
        <div>
            <h2>This is Message Page</h2>
        </div>
    );
};

export default Message;